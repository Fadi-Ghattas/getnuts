tinymce.addI18n('nl',{
	'Choose YouTube Video'  : 'Zoek YouTube Video',
	'Insert Youtube video'  : 'Voeg youtube video toe',
	'width'					: 'Breedte',
	'height'				: 'Hoogte',
	'skin'					: 'Skin',
	'dark'          		: 'dark',
	'light'         		: 'light',
	'Search'        		: 'Zoeken',
	'Youtube URL'   		: 'Youtube link',
	'Title'         		: 'Titel',
	'Insert and Close'		: 'Voeg toe en Sluit',
	'Insert'				: 'Voeg toe',
	'Load More'				: 'Meer laden',
	'cancel'				: 'cancel'
});
